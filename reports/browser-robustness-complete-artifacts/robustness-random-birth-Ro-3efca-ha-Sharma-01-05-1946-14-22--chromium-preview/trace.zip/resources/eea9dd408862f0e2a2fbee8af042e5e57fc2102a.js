let t=null;function n(e){t=e}function r(){return t}function u(){return t?.offsetHours??null}export{u as c,r as g,n as s};
