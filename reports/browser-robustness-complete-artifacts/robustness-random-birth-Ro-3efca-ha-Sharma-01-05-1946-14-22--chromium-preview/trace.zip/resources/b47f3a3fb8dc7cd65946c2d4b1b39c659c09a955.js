import{r as n,j as e,bq as l}from"./vendor-BLn7a-XD.js";import{S as c}from"./index-BHPrApHZ.js";import"./pdf-BGBv1QVn.js";import"./query-uBiMipNi.js";import"./radix-BbsK3BJ4.js";import"./auth-Cy76MWsg.js";import"./icons-DtkavYli.js";import"./animation-Dh7ndMFF.js";import"./analytics-CJ5B-FJP.js";import"./validation-B5OOJClE.js";const m=[{method:"POST",path:"/api/v1/chart/birth",description:"Calculate complete Vedic birth chart with all planetary positions, houses, and ascendant.",params:[{name:"date",type:"string",required:!0,description:"Birth date in YYYY-MM-DD format"},{name:"time",type:"string",required:!0,description:"Birth time in HH:MM format (24h)"},{name:"lat",type:"number",required:!0,description:"Birth latitude (-90 to 90)"},{name:"lon",type:"number",required:!0,description:"Birth longitude (-180 to 180)"},{name:"ayanamsa",type:"string",required:!1,description:"Ayanamsa system: lahiri (default), raman, krishnamurti"}],example:`POST /api/v1/chart/birth
{
  "date": "1990-03-15",
  "time": "06:30",
  "lat": 28.6139,
  "lon": 77.2090
}`,response:`{
  "ascendant": { "rashi": "Aquarius", "degrees": 15.3 },
  "planets": [
    { "name": "Sun", "rashi": "Pisces", "house": 2, "degrees": 24.5 },
    { "name": "Moon", "rashi": "Cancer", "house": 6, "degrees": 12.1 }
  ],
  "nakshatra": { "name": "Pushya", "pada": 2, "lord": "Saturn" }
}`},{method:"POST",path:"/api/v1/dasha/vimshottari",description:"Calculate Vimshottari Dasha periods for a birth chart.",params:[{name:"date",type:"string",required:!0,description:"Birth date in YYYY-MM-DD format"},{name:"time",type:"string",required:!0,description:"Birth time in HH:MM format"},{name:"lat",type:"number",required:!0,description:"Birth latitude"},{name:"lon",type:"number",required:!0,description:"Birth longitude"}],example:`POST /api/v1/dasha/vimshottari
{
  "date": "1990-03-15",
  "time": "06:30",
  "lat": 28.6139,
  "lon": 77.2090
}`,response:`{
  "currentMahadasha": { "planet": "Jupiter", "start": "2020-01-15", "end": "2036-01-15" },
  "currentAntardasha": { "planet": "Saturn", "start": "2024-03-10", "end": "2026-09-10" },
  "allPeriods": [...]
}`},{method:"POST",path:"/api/v1/compatibility/ashtakuta",description:"Calculate 36-point Ashtakuta compatibility between two birth charts.",params:[{name:"person1",type:"object",required:!0,description:"First person: { date, time, lat, lon }"},{name:"person2",type:"object",required:!0,description:"Second person: { date, time, lat, lon }"}],example:`POST /api/v1/compatibility/ashtakuta
{
  "person1": { "date": "1990-03-15", "time": "06:30", "lat": 28.61, "lon": 77.20 },
  "person2": { "date": "1992-07-22", "time": "14:15", "lat": 19.07, "lon": 72.87 }
}`,response:`{
  "totalScore": 28,
  "maxScore": 36,
  "compatibility": "Good",
  "categories": {
    "varna": { "score": 1, "max": 1 },
    "vashya": { "score": 2, "max": 2 },
    "nadi": { "score": 8, "max": 8 }
  }
}`},{method:"GET",path:"/api/v1/panchang/:date",description:"Get Panchang (Hindu almanac) for a specific date and location.",params:[{name:"date",type:"string",required:!0,description:"Date in YYYY-MM-DD format (URL parameter)"},{name:"lat",type:"number",required:!0,description:"Latitude (query parameter)"},{name:"lon",type:"number",required:!0,description:"Longitude (query parameter)"}],example:"GET /api/v1/panchang/2026-03-26?lat=28.6139&lon=77.2090",response:`{
  "tithi": { "name": "Tritiya", "number": 3, "paksha": "Shukla" },
  "nakshatra": { "name": "Rohini", "lord": "Moon" },
  "yoga": { "name": "Siddha", "number": 21 },
  "karana": { "name": "Bava", "number": 1 },
  "sunrise": "06:15", "sunset": "18:42"
}`},{method:"POST",path:"/api/v1/yogas/identify",description:"Identify all Vedic yogas present in a birth chart.",params:[{name:"date",type:"string",required:!0,description:"Birth date"},{name:"time",type:"string",required:!0,description:"Birth time"},{name:"lat",type:"number",required:!0,description:"Latitude"},{name:"lon",type:"number",required:!0,description:"Longitude"}],example:`POST /api/v1/yogas/identify
{
  "date": "1990-03-15",
  "time": "06:30",
  "lat": 28.6139,
  "lon": 77.2090
}`,response:`{
  "yogas": [
    { "name": "Gajakesari Yoga", "type": "Dhana", "strength": "Strong", "effect": "Wealth and wisdom" },
    { "name": "Hamsa Yoga", "type": "Pancha Mahapurusha", "strength": "Moderate", "effect": "Spiritual wisdom" }
  ],
  "totalYogas": 12
}`}],o={GET:"bg-green-100 text-green-800",POST:"bg-blue-100 text-blue-800"},N=()=>{const[a,i]=n.useState(null),[r,d]=n.useState("overview");return e.jsxs(e.Fragment,{children:[e.jsx(c,{title:"API Documentation - Vedic Astrology API",description:"Complete API documentation for the Vedic Astrology platform. Integrate birth charts, dasha, compatibility, panchang and more into your applications.",keywords:"astrology api, vedic astrology api, birth chart api, dasha api, panchang api, developer",canonical:"/api-docs"}),e.jsxs("div",{className:"min-h-screen bg-background",children:[e.jsx("header",{className:"border-b border-border bg-card",children:e.jsxs("div",{className:"container max-w-5xl mx-auto px-4 py-4 flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-3xl",children:"⚡"}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-xl font-bold",children:"API Documentation"}),e.jsx("p",{className:"text-xs text-muted-foreground",children:"v1.0 • REST API • JSON"})]})]}),e.jsx(l,{to:"/",className:"text-sm text-primary underline underline-offset-2",children:"Home"})]})}),e.jsxs("main",{className:"container max-w-5xl mx-auto px-4 py-8 space-y-6",children:[e.jsx("div",{className:"flex gap-1 bg-muted rounded-lg p-1",children:["overview","endpoints","auth","pricing"].map(t=>e.jsx("button",{onClick:()=>d(t),className:`flex-1 py-1.5 text-xs rounded-md font-medium transition-colors ${r===t?"bg-background shadow text-foreground":"text-muted-foreground"}`,children:t.charAt(0).toUpperCase()+t.slice(1)},t))}),r==="overview"&&e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"bg-card border rounded-xl p-5",children:[e.jsx("h2",{className:"font-bold mb-2",children:"Vedic Astrology REST API"}),e.jsx("p",{className:"text-sm text-muted-foreground mb-4",children:"Access the world's most comprehensive Vedic astrology calculations through our REST API. Build astrology apps, integrate into existing platforms, or create custom solutions."}),e.jsx("div",{className:"grid grid-cols-2 gap-3",children:[{label:"Base URL",value:"https://api.gocharphal.com/v1"},{label:"Format",value:"JSON"},{label:"Auth",value:"API Key (Bearer)"},{label:"Rate Limit",value:"1000 req/day (free)"}].map(t=>e.jsxs("div",{className:"bg-muted rounded-lg p-3",children:[e.jsx("div",{className:"text-xs text-muted-foreground",children:t.label}),e.jsx("div",{className:"text-sm font-mono font-medium",children:t.value})]},t.label))})]}),e.jsxs("div",{className:"bg-card border rounded-xl p-5",children:[e.jsx("h3",{className:"font-semibold mb-3",children:"Quick Start"}),e.jsx("pre",{className:"bg-muted rounded-lg p-4 text-xs overflow-x-auto",children:`curl -X POST https://api.gocharphal.com/v1/chart/birth \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "date": "1990-03-15",
    "time": "06:30",
    "lat": 28.6139,
    "lon": 77.2090
  }'`})]}),e.jsx("div",{className:"grid grid-cols-3 gap-3",children:[{label:"Endpoints",value:"25+",icon:"🔌"},{label:"Uptime",value:"99.9%",icon:"⚡"},{label:"Avg Response",value:"<100ms",icon:"🚀"}].map(t=>e.jsxs("div",{className:"bg-card border rounded-xl p-4 text-center",children:[e.jsx("div",{className:"text-2xl",children:t.icon}),e.jsx("div",{className:"font-bold",children:t.value}),e.jsx("div",{className:"text-xs text-muted-foreground",children:t.label})]},t.label))})]}),r==="endpoints"&&e.jsx("div",{className:"space-y-3",children:a?e.jsxs("div",{className:"space-y-4",children:[e.jsx("button",{onClick:()=>i(null),className:"text-sm text-primary flex items-center gap-1",children:"← All Endpoints"}),e.jsxs("div",{className:"bg-card border rounded-xl p-5",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx("span",{className:`text-xs px-2 py-0.5 rounded font-mono font-bold ${o[a.method]}`,children:a.method}),e.jsx("code",{className:"text-sm font-mono",children:a.path})]}),e.jsx("p",{className:"text-sm text-muted-foreground mb-4",children:a.description}),e.jsxs("div",{className:"mb-4",children:[e.jsx("div",{className:"text-sm font-medium mb-2",children:"Parameters"}),e.jsx("div",{className:"space-y-2",children:a.params.map(t=>e.jsxs("div",{className:"flex items-start gap-2 text-sm",children:[e.jsx("code",{className:"text-xs bg-muted px-1.5 py-0.5 rounded font-mono",children:t.name}),e.jsx("span",{className:"text-xs text-blue-600",children:t.type}),t.required&&e.jsx("span",{className:"text-xs text-red-500",children:"required"}),e.jsx("span",{className:"text-xs text-muted-foreground",children:t.description})]},t.name))})]}),e.jsxs("div",{className:"mb-4",children:[e.jsx("div",{className:"text-sm font-medium mb-2",children:"Example Request"}),e.jsx("pre",{className:"bg-muted rounded-lg p-3 text-xs overflow-x-auto",children:a.example})]}),e.jsxs("div",{children:[e.jsx("div",{className:"text-sm font-medium mb-2",children:"Example Response"}),e.jsx("pre",{className:"bg-muted rounded-lg p-3 text-xs overflow-x-auto",children:a.response})]})]})]}):m.map((t,s)=>e.jsxs("button",{onClick:()=>i(t),className:"w-full bg-card border rounded-xl p-4 text-left hover:border-primary transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:`text-xs px-2 py-0.5 rounded font-mono font-bold ${o[t.method]}`,children:t.method}),e.jsx("code",{className:"text-sm font-mono",children:t.path}),e.jsx("span",{className:"text-muted-foreground ml-auto",children:"→"})]}),e.jsx("p",{className:"text-xs text-muted-foreground mt-1",children:t.description})]},s))}),r==="auth"&&e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"bg-card border rounded-xl p-5",children:[e.jsx("h3",{className:"font-semibold mb-3",children:"Authentication"}),e.jsx("p",{className:"text-sm text-muted-foreground mb-3",children:"All API requests require authentication using an API key passed as a Bearer token in the Authorization header."}),e.jsx("pre",{className:"bg-muted rounded-lg p-3 text-xs",children:"Authorization: Bearer YOUR_API_KEY"})]}),e.jsxs("div",{className:"bg-card border rounded-xl p-5",children:[e.jsx("h3",{className:"font-semibold mb-3",children:"Get Your API Key"}),e.jsx("p",{className:"text-sm text-muted-foreground mb-3",children:"API keys are available for registered developers. Sign up to get your free API key with 1000 requests/day."}),e.jsx("button",{className:"bg-primary text-primary-foreground rounded-lg px-4 py-2 text-sm font-medium",children:"Get Free API Key (Coming Soon)"})]})]}),r==="pricing"&&e.jsx("div",{className:"grid grid-cols-1 gap-4",children:[{plan:"Free",price:"₹0/month",requests:"1,000/day",features:["All basic endpoints","Birth chart","Dasha","Panchang"],color:"border-gray-200"},{plan:"Developer",price:"₹999/month",requests:"10,000/day",features:["All endpoints","Compatibility","Yogas","Priority support"],color:"border-blue-300"},{plan:"Enterprise",price:"₹4,999/month",requests:"Unlimited",features:["All endpoints","White-label","SLA included","Dedicated support"],color:"border-purple-300"}].map(t=>e.jsxs("div",{className:`bg-card border-2 rounded-xl p-5 ${t.color}`,children:[e.jsxs("div",{className:"flex items-center justify-between mb-3",children:[e.jsx("div",{className:"font-bold text-lg",children:t.plan}),e.jsx("div",{className:"text-xl font-bold text-primary",children:t.price})]}),e.jsxs("div",{className:"text-sm text-muted-foreground mb-3",children:[t.requests," requests"]}),e.jsx("ul",{className:"space-y-1",children:t.features.map(s=>e.jsxs("li",{className:"text-sm flex items-center gap-2",children:[e.jsx("span",{className:"text-green-500",children:"✓"}),s]},s))}),e.jsx("button",{className:"w-full mt-4 border rounded-lg py-2 text-sm font-medium hover:bg-muted transition-colors",children:"Get Started"})]},t.plan))})]})]})]})};export{N as default};
